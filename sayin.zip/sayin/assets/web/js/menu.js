// Captura os elementos do input e do botão
const searchInput = document.getElementById('search');
const searchButton = document.getElementById('searchBtn');

// Adiciona um evento de clique ao botão de busca
searchButton.addEventListener('click', performSearch);

// Adiciona um evento de pressionar a tecla "Enter" no input
searchInput.addEventListener('keypress', function(event) {
  if (event.key === 'Enter') {
    performSearch();
  }
});

// Função que executa a busca
function performSearch() {
  const searchTerm = searchInput.value;
  // Aqui você pode adicionar o código para realizar a busca com o termo pesquisado
  // Por exemplo, redirecionar para uma página de resultados ou exibir os resultados na mesma página.
  console.log('Buscando por:', searchTerm);
}
