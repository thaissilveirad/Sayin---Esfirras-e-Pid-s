<?php
    $this->layout("_theme",[]);
?>

<h1>Área de Aplicação</h1>