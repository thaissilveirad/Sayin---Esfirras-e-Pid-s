<h2>Olá, Aqui você pode fazer perguntas e nós respondemos</h2>

<button>Perguntas e Respostas</button>

<div id="divFaqs">
</div>

<script type="module" async>
    import {request, requestDebugError} from "<?php echo url("/assets/_shared/functions.js"); ?>";

    // http://localhost/escola-manha/api/faqs
    const url = "<?php echo url("/api/faqs"); ?>";
    //criar rotas e fazer aparecer na tela!!

    const options = {
        method: "GET"
    };

    const getFaqs = async () => {
        const faqs = await request(url, options);
        //console.log(faqs);
    };

    getFaqs();

    const button = document.querySelector("button");
    button.addEventListener("click", async () => {
        const faqs = await request(url, options);
        //console.log(faqs);
        faqs.forEach((faq) => {
            //console.log(faq);
            document.querySelector("#divFaqs").insertAdjacentHTML("beforeend", `<p>${faq.question} ${faq.answer}</p>`);
        });
    });
</script>

<style>
/* Estilos gerais */
body {
  font-family: Arial, sans-serif;
  margin: 0;
  padding: 0;
  background-color: #262626;
  text-align: center;
}

h2 {
  font-size: 24px;
  margin-top: 20px;
}

button {
  background-color: #333;
  color: #fff;
  padding: 10px 20px;
  border: none;
  cursor: pointer;
}

button:hover {
  background-color: #555;
}

/* Estilizar o contêiner das perguntas e respostas */
#divFaqs {
  max-width: 800px;
  margin: 20px auto;
  padding: 20px;
  background-color: #fff;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.2);
  border-radius: 10px;
}

/* Estilizar cada pergunta e resposta individualmente */
#divFaqs p {
  font-size: 16px;
  margin: 10px 0;
  padding: 10px;
  background-color: #f4f4f4;
  border-radius: 5px;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
}

/* Estilizar as perguntas (assumindo que as perguntas estão em negrito) */
#divFaqs p strong {
  font-weight: bold;
  color: #333;
}

/* Estilizar as respostas (assumindo que as respostas estão em itálico) */
#divFaqs p em {
  font-style: italic;
  color: #555;
}



</style>