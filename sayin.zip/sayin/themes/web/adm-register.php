
<?php
    $this->layout("_theme", ["categories" => $categories]);
?>

    <div class="container register" data-aos="fade-up">
        <div class="row">
            <div class="col-lg-6">
            <form role="form" class="php-email-form">
            <h2>Cadastre-se para se tornar um administrador.</h2>
                <div class="form-group mt-3">
                    <input type="text" class="form-control" name="name" id="subject" placeholder="Seu nome">
                </div>
                <div class="form-group mt-3">
                    <input type="text" class="form-control" name="email" id="subject" placeholder="Seu email">
                </div>
                <div class="form-group mt-3">
                    <input type="text" class="form-control" name="password" id="subject" placeholder="Sua senha">
                </div>
                <div class="form-group mt-3">
                    <input type="text" class="form-control" name="address" id="subject" placeholder="Seu endereço">
                </div>
                <div class="form-group mt-3">
                    <input type="text" class="form-control" name="access" id="subject" placeholder="Chave de acesso">
                </div>
                <div class="my-3">
                    <div class="loading"></div>
                    <div class="error-message"></div>
                    <div class="sent-message"></div>
                    <a id="entre" href="<?= url("/adm-login")?>">Ja é um administrador?? Faça login!</a>
                </div>
                <a href="<?= url("/admin")?>"><div class="text-center"><button type="submit">Cadastrar</button></div></a>
            </form>
    </div>
    </div>
    </div>

