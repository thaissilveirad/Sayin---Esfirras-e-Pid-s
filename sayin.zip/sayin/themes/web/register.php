
<?php
    $this->layout("_theme", ["categories" => $categories]);
?>

<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST["name"];
    $email = $_POST["email"];
    $password = $_POST["password"];
    $address = $_POST["address"];

    if(empty($name) || empty($email) || empty($password) || empty($address)) {
        echo "Preencha todos os campos.";
    }else {
        echo "Usuário cadastrado com sucesso!";
    }
}
?>
    <div class="container register" data-aos="fade-up">
        <div class="row">
            <div class="col-lg-6">
            <form role="form" class="php-email-form">
            <h2>Cadastre-se grátis para continuar.</h2>
                <div class="form-group mt-3">
                    <input type="text" class="form-control" name="name" id="subject" placeholder="Seu nome">
                </div>
                <div class="form-group mt-3">
                    <input type="text" class="form-control" name="email" id="subject" placeholder="Seu email">
                </div>
                <div class="form-group mt-3">
                    <input type="text" class="form-control" name="password" id="subject" placeholder="Sua senha">
                </div>
                <div class="form-group mt-3">
                    <input type="text" class="form-control" name="address" id="subject" placeholder="Seu endereço">
                </div>
                <div class="my-3">
                    <div class="loading"></div>
                    <div class="error-message"></div>
                    <div class="sent-message"></div>
                    <a id="entre" href="<?= url("/login")?>">Ja possui uma conta? Faça login!</a>
                </div>
                <div class="text-center"><button type="submit">Cadastrar</button></div>
            </form>
    </div>
    </div>
    </div>

<script type="text/javascript" async>
    const form = document.querySelector(".php-email-form");
    const sentMessage = document.querySelector(".sent-message");
    const errorMessage = document.querySelector(".error-message");

    const headers = {
            email: "",
            password: ""
    };

    form.addEventListener("submit", async (e) => {
        e.preventDefault();
        //console.log(new FormData(form));
        const data = await fetch(`<?= url("api/user");?>`,{
            method: "POST",
            body: new FormData(form),
            headers: headers
        });
        const user = await data.json();
        console.log(user);

        if (user.success) {
            sentMessage.textContent = "Cadastro realizado com sucesso!";
            sentMessage.style.display = "block";
            form.reset();
        }else if(email == "" || name == "" || password == "" || address == "") {
            errorMessage.textContent = "Erro ao cadastrar usuário.";
            errorMessage.style.display = "block";
        }

    });
</script>