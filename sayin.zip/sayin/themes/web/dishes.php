<?php
 $this->layout("_theme", 
 ["categories" =>  $categories]);
?>

    
 <!-- <div>
<div class="content">
    <div class="nav" id="nav">
      <input type="search" id="search" placeholder="Pesquisar 🔍">
      <button id="searchBtn">Buscar</button>
      </div>
      <ul>
      <;;?php
      foreach ($categories as $category) {
        ?>
       <li><a href="<;;?= url("dishes/{$category->name}"); ?>"><;;?= $category->name; ?></a></li>
       <;;?php
       }
      ?>
      </ul>
    <hr>
 
        <;;?php
          foreach ($dishes as $dish) {
        ?>
      <div id="prod">
        <div id="item">
          <div id="texto" >
            <h3><;;?= $dish->name; ?></h3>
            <p><;;?= $dish->description; ?></p>
            <br>
            <p><sup>R$</sup><;;?= $dish->price; ?></p>
          </div>
          <hr>
        </div>
     <;;?php
          }
     ?>

        </div>
        </div>  -->



<section id="pricing" class="pricing section-bg">
    <div class="container" data-aos="fade-up">

        <div class="section-title">
            <h2>Cardápio</h2>
        </div>

        <div class="row">


                <?php
                foreach ($dishes as $dish) {
                ?>
                 <h3><?= $dish->name; ?></h3>
                    <h4><sup>R$</sup><?= ($dish->price); ?></h4>
                <div class="col-lg-3 col-md-6 mt-4 mt-md-0" data-aos="fade-up" data-aos-delay="200">
               
                <div class="box featured">
                  
                    <ul>
                        <!-- <li><;;?= $dish->abstract; ?></li> -->
                    </ul>
                    <div class="btn-wrap">
                        <a href="#" class="btn-buy">Adicionar ao carrinho</a>
                        <hr>
                    </div>
                </div>
                </div>
                <?php
                }
                ?>

        </div>

    </div>
</section>