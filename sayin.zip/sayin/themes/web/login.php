<?php
$this->layout(
    "_theme",
    ["categories" => $categories]
);
?>

<!-- <div id="form">
    <h2>Bem-vindo, faça login para continuar.</h2>
    <form>
        <div>
            <input name="email" type="text" placeholder="Seu email">
        </div>
        <div>
           <input name="password" type="text" placeholder="Sua senha">
        </div>
        <a id="cadastre" href="<?= url("/register") ?>">Não tem uma conta? Cadastre-se</a>
        <div>
            <button>Entrar</button>
        </div>
        <div class="response">

        </div>
    </form>
</div> -->

<div class="container login" data-aos="fade-up">
        <div class="row">
            <div class="col-lg-6">
            <form role="form" class="php-email-form">
            <h2>Bem-vindo, faça login para continuar.</h2>
                <div class="form-group mt-3">
                    <input type="text" class="form-control" name="email" id="subject" placeholder="Seu email">
                </div>
                <div class="form-group mt-3">
                    <input type="text" class="form-control" name="password" id="subject" placeholder="Sua senha">
                </div>
                <div class="my-3">
                    <span class="status"></span>
                    <div class="error-message"></div>
                    <a id="entre" href="<?= url("/register")?>">Não tem uma conta? Cadastre-se!</a>
                </div>
                <div class="text-center"><button type="submit">Entrar</button></div>
            </form>
    </div>
    </div>
    </div>

<script type="text/javascript" async>
    const url = `<?= url("api/user/login"); ?>`;

    async function request(url, options) {
        try {
            const response = await fetch(url, options);
            const data = await response.json();
            return data;
        } catch (err) {
            console.error(err);
            return {
                type: "error",
                message: err.message
            };
        }
    }

    let status = document.querySelector(".status");

    document.querySelector("form").addEventListener("submit", async (e) => {
        e.preventDefault();
        const formData = new FormData(document.querySelector("form"));
        const options = {
            method: 'POST',
            body: formData
        };
        const resp = await request(url, options);
        // console.log(resp);
        status.innerHTML = `${resp.message}`;
    });

</script>