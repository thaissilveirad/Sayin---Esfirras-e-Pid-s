<?php
$this->layout(
    "_theme",
    ["categories" => $categories]
);
?>


<div class="container login" data-aos="fade-up">
    <div class="row">
        <div class="col-lg-6">
            <form role="form" class="php-email-form">
                <h2>Opa, acesso restrito..</h2>
                <h3>Somente administradores podem acessar a área administrativa. Se você é um administrador, valide sua
                    identidade para continuar.
                    <div class="form-group mt-3">
                        <input type="text" class="form-control" name="email" id="subject" placeholder="Seu email">
                    </div>
                    <div class="form-group mt-3">
                        <input type="text" class="form-control" name="password" id="subject" placeholder="Sua senha">
                    </div>
                    <div class="my-3">
                        <span class="status"></span>
                        <div class="error-message"></div>
                        <a id="entre" href="<?= url("/adm-register") ?>">Deseja cadastrar-se como administrador? Clique aqui!</a>
                    </div>
                    <a href="<?= url("/admin")?>"><div class="text-center"><button type="submit">Entrar</button></div></a>
            </form>
        </div>
    </div>
</div>

