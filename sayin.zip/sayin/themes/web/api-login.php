<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login com API</title>
    <style>
        /* Estilo para o corpo da página */
        body {
            font-family: Arial, sans-serif;
            background-color: #262626;
            margin: 0;
            padding: 0;
        }

        /* Estilo para o formulário de login */
        #formLogin {
            max-width: 400px;
            margin: 0 auto;
            background-color: #ffc800;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        #formLogin div {
            margin-bottom: 10px;
        }

        #formLogin input[type="text"], #formLogin input[type="password"] {
            width: 100%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 3px;
        }

        #formLogin button {
            width: 100%;
            padding: 10px;
            background-color: #ffc8;
            color: #fff;
            border: none;
            border-radius: 3px;
            cursor: pointer;
        }

        #formLogin button:hover {
            background-color: #ff4f;
        }

        /* Estilo para o botão "Lista de Endereços" */
        #listAddress {
            display: block;
            width: 200px;
            margin: 20px auto;
            padding: 10px;
            background-color:  #ffc800;
            color: #fff;
            border: none;
            border-radius: 3px;
            cursor: pointer;
        }

        #listAddress:hover {
            background-color: #ff4f;
        }

        /* Estilo para a lista de endereços */
        #address {
            max-width: 400px;
            margin: 0 auto;
            background-color:  #ffc800;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        /* Estilo para erros ou mensagens de debug */
        #errorMessage {
            color: red;
            margin-top: 10px;
        }
    </style>
</head>
<body>
    <h1>Login com API</h1>
    <div>
        <form id="formLogin">
            <div>E-mail: <input type="text" id="email" name="email" value=""></div>
            <div>Password: <input type="password" id="password" name="password" value=""></div>
            <button type="submit">Login</button>
        </form>
    </div>
    <div>
        <button id="listAddress">Lista De Endereços</button>
    </div>
    <!-- Div para exibir mensagens -->
   
    <div id="address">
        Lista
    </div>     

    <script type="module" async>
    function printMessage(message) {
        const outputDiv = document.querySelector("#address");
        const messageDiv = document.createElement("div");
        messageDiv.textContent = message;
        outputDiv.appendChild(messageDiv);
    }

    import { request, requestDebugError } from "<?php echo url("/assets/_shared/functions.js"); ?>";

    const formLogin = document.querySelector("#formLogin");

    formLogin.addEventListener("submit", (event) => {
        event.preventDefault();

        const urlLogin = "<?= url("api/user/login"); ?>";
        const options = {
            method: "get",
            headers: {
                email: document.querySelector("#email").value,
                password: document.querySelector("#password").value,
            },
        };

        fetch(urlLogin, options)
            .then((response) => {
                response.json()
                    .then((user) => {
                        localStorage.setItem("userLogin", JSON.stringify(user));
                        printMessage("Login bem-sucedido.");
                    })
                    .catch((error) => {
                        printMessage("Erro no login: " + error.message);
                    });
            })
            .catch((error) => {
                printMessage("Erro na requisição: " + error.message);
            });
    });

    document.querySelector("#listAddress").addEventListener("click", () => {
        const userLogin = JSON.parse(localStorage.getItem("userLogin"));
        console.log(userLogin.user.token);
        const optionsAddress = {
            method: "get",
            headers: {
                token: userLogin.user.token,
            },
        };
        const urlAddress = "<?= url("api/user/adresses"); ?>";
        
        fetch(urlAddress, optionsAddress)
            .then((response) => {
                if (response.ok) {
                    return response.json();
                } else {
                    throw new Error("Erro ao buscar endereços");
                }
            })
            .then((addresses) => {
                console.log(addresses);
                addresses.forEach((address) => {
                    const addressMessage = `Rua: ${address.street}, Número: ${address.number}, Complemento:${address.complement}`;
                    printMessage(addressMessage);
                });
            })
            .catch((error) => {
                printMessage("Erro ao buscar endereços: " + error.message);
            });
    });
</script>

</body>
</html>