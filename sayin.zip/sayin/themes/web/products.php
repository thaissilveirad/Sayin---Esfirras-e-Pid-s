<?php
$this->layout(
    "_theme",
    ["categories" => $categories]
);
?>

<!-- Produtos-->
<section class="page-section" id="produtos">
        <div class="container">
            <div class="text-center">
                <h2 class="section-heading text-uppercase">Produtos</h2>
                <h3 class="section-subheading text-muted">Conheça nosso cardápio.</h3>
            </div>


<div class="container-fluid border p-5">

<div class="row">

    <div class="col">
        <h2>Esfirras Salgadas</h2>
             <div class="listaproduto-img">
                <img class="img-fluid imgprodutos" src="assets/web/assets/img/back/esfiha-salgada.jpg" alt="Esfirras Salgadas">
             </div>
    </div>
            
</div>

<div class="row">
    <div class="col">
        <h2>Esfirras Doces</h2>
             <div class="listaproduto-img">
                <img class="img-fluid imgprodutos" src="assets/web/assets/img/back/esfiha-doce.jpg" alt="Esfirras Doces">
             </div>
    </div>
</div>

<div class="row">
    <div class="col">
        <h2>Pidês Salgadas</h2>
             <div class="listaproduto-img">
                <img class="img-fluid imgprodutos" src="assets/web/assets/img/back/pide-salgada.jpeg" alt="Pidês Salgadas">
             </div>
    </div>
</div>

<div class="row">
    <div class="col">
        <h2>Pidês Doces</h2>
             <div class="listaproduto-img">
                <img class="img-fluid imgprodutos" src="assets/web/assets/img/back/pide-doce.jpeg" alt="Pidês Doces">
             </div>
    </div>
</div>

</div>
</section>


