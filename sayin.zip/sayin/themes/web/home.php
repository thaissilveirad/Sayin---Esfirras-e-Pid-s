<?php
  $this->layout("_theme", [
    "categories" => $categories
  ]);
?>

    <!-- Cabeçalho-->
    <header class="masthead">
        <div class="container">
            <div class="masthead-subheading">Sayin - Esfirras e Pidês</div>
            <div class="masthead-heading text-uppercase">Bateu a fome de comida Árabe?</div>
            <a class="btn btn-primary btn-xl text-uppercase" href="<?= url("/produtos")?>">Saiba mais</a>
        </div>
    </header>

      <!-- Footer-->
  <footer class="footer py-4">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-lg-4 text-lg-start">Copyright &copy; Your Website 2023</div>
                    <div class="col-lg-4 my-3 my-lg-0">
                        <a class="btn btn-dark btn-social mx-2" href="#!" aria-label="Twitter"><i class="fab fa-twitter"></i></a>
                        <a class="btn btn-dark btn-social mx-2" href="#!" aria-label="Facebook"><i class="fab fa-facebook-f"></i></a>
                        <a class="btn btn-dark btn-social mx-2" href="#!" aria-label="LinkedIn"><i class="fab fa-linkedin-in"></i></a>
                    </div>
                    <div class="col-lg-4 text-lg-end">
                        <a class="link-dark text-decoration-none me-3" href="#!">Política de Privacidade</a>
                        <a class="link-dark text-decoration-none" href="#!">Termos de Uso</a>
                    </div>
                </div>
            </div>
        </footer>