<?php
$this->layout(
  "_theme",
  ["categories" => $categories]
);
?>

<?php
//    if(!empty($faqs)){
//        //var_dump($faqs);
//        foreach ($faqs as $faq){
//            //var_dump($faq);
//            echo "<div>{$faq->question} - {$faq->answer}</div>";
//        }
//    }
?>




<div class="heading_container heading_center">
</div>


<div class="container">
  <h1>Perguntas Frequentes</h1>

  <table class="table table-striped">
    <thead>
      <tr>
        <th scope="col">Pergunta</th>
        <th scope="col">Resposta</th>
      </tr>
    </thead>
    <tbody>

      <?php
      foreach ($faqs as $faq) {
        ?>

        <tr>
          <td>
            <?= $faq->question; ?>
          </td>
          <td>
            <?= $faq->answer; ?>
          </td>
        </tr>

      <?php
      }
      ?>

    </tbody>
  </table>


  <section id="submit-question">
    <h2>Deseja enviar uma pergunta?</h2>
    <form action="submit_question.php" method="post">
      <label for="question">Responderemos assim que possível.</label>
      <input type="text" id="question" name="question" required placeholder="Deixe sua dúvida aqui">
      <br>
      <button type="submit">Enviar Pergunta</button>
    </form>
  </section>


  <style>
    #submit-question {
      padding: 20px;
      margin: 20px;
      border: 1px solid gray;
    }

    #submit-question form {
      display: flex;
      flex-direction: column;
    }

    #submit-question label {
      margin-bottom: 10px;
    }

    #submit-question input[type="text"] {
      padding: 10px;
      border: 1px solid gray;
      background-color: #262626;
    }

    #submit-question button {
      color: #FFC02E;
      border: none;
      padding: 10px 20px;
      cursor: pointer;
      background-color: #262626;
    }

    #submit-question button:hover {
      background-color: #262524;
    }
  </style>


</div>