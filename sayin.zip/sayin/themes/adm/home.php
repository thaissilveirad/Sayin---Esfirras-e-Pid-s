<?php
$this->layout("_theme", ["categories" => $categories]);
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <title>Sayin - Esfirras e Pidês</title>
    <!-- Favicon-->
    <link rel="icon" type="image/x-icon" href="assets/favicon.ico" />
    <!-- Font Awesome icons (free version)-->
    <script src="https://use.fontawesome.com/releases/v6.3.0/js/all.js" crossorigin="anonymous"></script>
    <!-- Google fonts-->
    <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700" rel="stylesheet" type="text/css" />
    <link href="https://fonts.googleapis.com/css?family=Roboto+Slab:400,100,300,700" rel="stylesheet" type="text/css" />
    <!-- Core theme CSS (includes Bootstrap)-->
    <link rel="stylesheet" href="<?= url("/assets/web/css/styles.css") ?>">
    <link rel="stylesheet" href="<?= url("/assets/web/css/meucss.css") ?>">
    <link rel="stylesheet" href="<?= url("/assets/web/css/profile.css") ?>">
    <script type="text/javascript" src="<?= url("/assets/web/js/script.js") ?>" async></script>
    <script type="text/javascript" src="<?= url("/assets/web/js/menu.js") ?>" async></script>
</head>


<body id="top">
    <!-- Nav-->
    <nav class="navbar navbar-expand-lg navbar-dark fixed-top" id="mainNav">
        <div class="container">
            <a class="navbar-brand" href="<?= url("/") ?>">Sayin</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarResponsive"
                aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
                Menu
                <i class="fas fa-bars ms-1"></i>
            </button>
            <div class="collapse navbar-collapse" id="navbarResponsive">
                <ul class="navbar-nav text-uppercase ms-auto py-4 py-lg-0">
                    <li class="nav-item"><a class="nav-link" href="<?= url("/") ?>">Início</a></li>
                    <li class="nav-item"><a class="nav-link" href="<?= url("/produtos"); ?>">Produtos</a></li>
                    <li class="nav-item"><a class="nav-link" href="<?= url("/sobre"); ?>">Sobre</a></li>
                    <li class="nav-item"><a class="nav-link" href="<?= url("/pratos") ?>">Menu</a></li>
                    <li class="nav-item"><a class="nav-link" href="<?= url("/login") ?>">Entrar</a></li>
                    <li class="nav-item"><a class="nav-link" href="<?= url("/faq") ?>">Faqs</a></li>
                    <li class="nav-item"><a class="nav-link" href="<?= url("/perfil") ?>">👤</a></li>
                    <li class="nav-item"><a class="nav-link" href="<?= url("/carrinho") ?>">carrinho</a></li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- POG -->
    <div style="height: 94px"></div>

    <?php
    echo $this->section("content");
    ?>

    <area-adm>

        <body>
            <header>
                <h1>Área Administrativa</h1>
            </header>
            <nav>
                <ul>
                    <li><a href="#gerenciamento-produtos">Gerenciamento de Produtos</a></li>
                    <li><a href="#gerenciamento-clientes">Gerenciamento de Clientes</a></li>
                </ul>
            </nav>

            <div class="container">
                <section id="gerenciamento-clientes">
                    <h2>Gerenciamento de Clientes</h2>
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th scope="col">Usuários Cadastrados:</th>
                            </tr>
                        </thead>
                        <tbody>

                            <?php
                            foreach ($users as $user) {
                                ?>

                                <tr>
                                    <td>
                                        <?= $user->name ?> -
                                        <?= $user->email ?>
                                        <a href="editar_produto.php?id=<?= $user->id ?>">Editar</a>
                                        <a href="excluir_produto.php?id=<?= $user->id ?>">Excluir</a>
                                    </td>

                                </tr>

                                <?php
                            }
                            ?>

                        </tbody>
                    </table>

                    <form action="adicionar_produto.php" method="POST">
                        <label for="user-name">Nome:</label>
                        <input type="text" id="product-name" name="product-name" required>
                        <label for="user-email">Email:</label>
                        <input type="email" id="user-email" name="user-email" required>
                        <label for="user-pass">Senha:</label>
                        <input type="password" id="user-pass" name="user-pass" required>
                        </select>
                        <button type="submit">Adicionar Cliente</button>
                    </form>
                </section>
            </div>


            <section id="gerenciamento-produtos">
                <h2>Gerenciamento de Produtos</h2>
                <section id="gerenciamento-produtos">
                    <div class="container">
                        <table class="table table-striped">
                            <thead>
                                <tr>
                                    <th scope="col">Produtos Existentes:</th>
                                </tr>
                            </thead>
                            <tbody>

                                <?php
                                foreach ($dishes as $dish) {
                                    ?>

                                    <tr>
                                        <td>
                                            <?= $dish->name ?> - R$
                                            <?= $dish->price ?> -
                                            <a href="editar_produto.php?id=<?= $dish->id ?>">Editar</a>
                                            <a href="excluir_produto.php?id=<?= $dish->id ?>">Excluir</a>

                                        </td>

                                    </tr>

                                    <?php
                                }
                                ?>

                            </tbody>
                        </table>

                        <form action="adicionar_produto.php" method="POST">
                            <label for="product-name">Nome do Produto:</label>
                            <input type="text" id="product-name" name="product-name" required>
                            <label for="product-category">Categoria:</label>
                            <select id="product-category" name="product-category">
                                <?php foreach ($categories as $category): ?>
                                    <option value="<?= $category->id ?>">
                                        <?= $category->name ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                            <label for="product-price">Preço:</label>
                            <input type="number" id="product-price" name="product-price" step="0.01" required>
                            <button type="submit">Adicionar Produto</button>
                        </form>

                    </div>



        </body>


        <style>
            body {
                font-family: Arial, sans-serif;
                margin: 0;
                padding: 0;
            }

            header {
                background-color: #262626;
                color: white;
                text-align: center;
                padding: 20px;
            }

            nav ul {
                list-style: none;
                padding: 10px;
                margin: 0;
            }

            nav ul li {
                display: inline;
                margin-right: 20px;
            }

            nav ul li a {
                text-decoration: none;
                color: white;
            }

            section {
                padding: 20px;
                margin: 20px;
                background-color: #262626;
                border: 1px solid gray;
            }
        </style>

    </area-adm>


</body>

</html>