<?php

namespace Source\App\Api;

use Source\Models\Dish;

class Dishes extends Api
{
    public function __construct()
    {
        header('Content-Type: application/json; charset=UTF-8');
    }

    public function listByCategory (array $data) : void
    {
        $dishes = (new Dish())->selectByCategoryId($data["category_id"]);
        $this->back($dishes,200);
    }

    public function listDishes (array $data) : void
    {
        $dishes = (new Dish())->selectAll();
        $this->back($dishes,200);
    }

    public function getDish(array $data): void
    {
        $dish = (new Dish())->selectById($data["dish_id"]);
        $this->back($dish,200);
    }

    public function updateDish(array $data): void
    {

        $dish = (new Dish(
            $data["id"],
            $data["name"],
            $data["category_id"],
            $data["price"],
            NULL
        ))->update();

        $response = [
            "type" => "success",
            "message" => "Curso atualizado com sucesso"
        ];

        $this->back($response,200);
    }

    

}