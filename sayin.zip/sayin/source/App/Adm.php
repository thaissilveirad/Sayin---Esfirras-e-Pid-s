<?php

namespace Source\App;

use League\Plates\Engine;
use Source\Models\Category;
use Source\Models\Dish;
use Source\Models\Faq;
use Source\Models\User;

class Adm
{
    private $view;

    public function __construct ()
    {
        $this->view = new Engine(__DIR__ . "/../../themes/adm","php");
    }

    public function home()
    {
        $categories = new Category();
        $dishes = new Dish();
        $faqs = new Faq();
        $users = new User();
        // var_dump($dishes->selectAll());
        echo $this->view->render(
            "home", ["categories" => $categories->selectAll(),
                     "dishes" => $dishes->selectAll(),
                     "faqs" => $faqs->selectAll(),
                     "users" => $users->selectAll()]
        );
        
       // echo "Olá";
    }

    public function menu()
    {
        echo $this->view->render(
            "menu"
        );
    }
    public function dishes()
    {
        $categories = new Category();

        echo $this->view->render(
            "dish", ["categories" => $categories->selectAll()]
        );
    }
}
