<?php

namespace Source\App;

use League\Plates\Engine;
use Source\Models\Category;
use Source\Models\Dish;
use Source\Models\Faq;

class Web
{

    private $view;
    private $categories;

    public function __construct () 
    {
        $this->view = new Engine( __DIR__ . "/../../themes/web", "php");
        $category = new Category;
        $this->categories = $category->selectAll();
    }

    public function home()
    {
        echo $this->view->render("home",[
            "categories" => $this->categories
        ]);
    }

    public function register(array $data)
    {
        if(!empty($data)){
            $response = json_encode($data);
            echo $response;
            return;
        }

        echo $this->view->render("register",[
            "categories" => $this->categories
        ]);
    }

    public function login(array $data) : void
    {
        echo $this->view->render("login", [
            "categories" => $this->categories
        ]);
    }

    public function about()
    {
        echo $this->view->render("about",[
            "categories" => $this->categories
        ]);    
    }

    public function profile (){
        echo $this->view->render("profile", [
            "categories" => $this->categories
        ]);
    }

    public function faq ()
    {
        $faq = new Faq();
        $faqs = $faq->selectAll();

        echo $this->view->render("faq",[
            "faqs" => $faqs,
            "categories" => $this->categories
        ]);
    }

    public function apiFaq (array $data)
    {
        echo $this->view->render("api-faqs",[]);
    }

    public function apiLogin (): void
    {
        echo $this->view->render("api-login",[]);
    }
    public function apiRegister (): void
    {
        echo $this->view->render("api-register",[]);
    }

    public function products (){
        echo $this->view->render("products", [
            "categories" => $this->categories
        ]);
    }


    public function dishes (array $data) : void 
    {

        $categories = new Category();
        $dishes = new Dish();

        if(!empty($data["categoryName"])) {
            echo $this->view->render("dishes", [
                "dishes" => $dishes->selectByCategory($data["categoryName"]),
                "categories" => $this->categories

            ]);
            return;
        }

        echo $this->view->render("dishes", [
            "dishes" => $dishes->selectAll(),
            "categories" => $this->categories
        ]);


    }

 



    

    public function cart (){
        echo $this->view->render("cart", [
            "categories" => $this->categories
        ]);
    }


    public function admLogin (){
        echo $this->view->render("adm-login", [
            "categories" => $this->categories
        ]);
    }

    public function admRegister (){
        echo $this->view->render("adm-register", [
            "categories" => $this->categories
        ]);
    }




    public function alteration()
    {
       
        echo $this ->view -> render ("alteration");
    }
  

    public function productsinsert()
    {
       
        echo $this ->view -> render ("productsinsert");
    }



    public function apiAddress (array $data)
    {
        echo $this->view->render ("api-address");
    }
    public function apilistproducts (array $data)
    {
        echo $this->view->render ("api-listproducts");
    }



        public function product (array $data) : void {

            //var_dump($data);

            $products = new Product();

                //var_dump($products->selectByCategory($data["categoryName"]));            

            if(!empty($data["categoryName"])){
                echo $this->view->render("products", ["products" => $products->selectByCategory($data["categoryName"])]);
                return;
            }
            //var_dump($products->selectAll());
            //var_dump($data["categoryName"]);
            echo $this->view->render("products", ["products" => $products->selectAll() ]);

        }
}