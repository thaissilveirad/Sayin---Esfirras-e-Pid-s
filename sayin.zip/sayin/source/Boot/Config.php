<?php

const CONF_DB_HOST = "localhost";
const CONF_DB_USER = "root";
const CONF_DB_PASS = "";
const CONF_DB_NAME = "bd_sayin";


const CONF_URL_BASE = "http://www.localhost/sayin"; 
const CONF_URL_TEST = "http://www.localhost/sayin"; 