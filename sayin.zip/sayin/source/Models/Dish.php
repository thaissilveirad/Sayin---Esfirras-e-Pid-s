<?php

namespace Source\Models;

use Source\Core\Connect;

class Dish
{
    private $id;
    private $name;
    private $category_id;
    private $price;
    private $description;

    public function __construct(int $id = null, string $name = null, int $categoryId = null, float $price = null, string $description = null)
    {
        $this->id = $id;
        $this->name = $name;
        $this->category_id = $categoryId;
        $this->price = $price;
        $this->description = $description;
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    public function setId(?int $id): void
    {
        $this->id = $id;
    }

    public function getName(): ?string
    {
        return $this->name;
    }

    public function setName(?string $name): void
    {
        $this->name = $name;
    }

    public function getCategoryId(): ?int
    {
        return $this->category_id;
    }

    public function setCategoryId(?int $category_id): void
    {
        $this->category_id = $category_id;
    }

    public function getPrice(): ?float
    {
        return $this->price;
    }

    public function setPrice(?float $price): void
    {
        $this->price = $price;
    }

    public function getDescription(): ?string
    {
        return $this->description;
    }

    public function setDescription(?string $description): void
    {
        $this->description = $description;
    }

    public function selectAll ()
    {
        $query = "SELECT * FROM dishes";
        $stmt = Connect::getInstance()->query($query);
        return $stmt->fetchAll();
    }

    public function selectById (int $id)
    {
        $query = "SELECT * FROM courses WHERE id = {$id}";
        $stmt = Connect::getInstance()->query($query);
        return $stmt->fetchAll();
    }

    public function selectByCategory(string $categoryName)
    {
        $query = "SELECT dishes.* 
                  FROM dishes 
                  JOIN categories ON categories.id = dishes.category_id 
                  WHERE categories.name LIKE '{$categoryName}'";
        $stmt = Connect::getInstance()->query($query);
        return $stmt->fetchAll();
    }

    public function selectByCategoryId(int $categoryId)
    {
        $query = "SELECT dishes.* 
                  FROM dishes 
                  JOIN categories ON categories.id = dishes.category_id 
                  WHERE dishes.category_id = {$categoryId}";
        $stmt = Connect::getInstance()->query($query);
        return $stmt->fetchAll();
    }

    public function update ()
    {
        $query = "UPDATE courses 
                  SET name = '{$this->name}',  category_id = {$this->category_id}, price = {$this->price} 
                  WHERE id = {$this->id}";

        $stm = Connect::getInstance()->query($query);

    }

}