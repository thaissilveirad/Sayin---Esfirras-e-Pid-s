<?php

require __DIR__ . "/vendor/autoload.php";

use CoffeeCode\Router\Router;

ob_start();

$route = new Router(url(), ":");

$route->namespace("Source\App");

$route->group(null);



$route->get("/produtos","Web:products");
$route->get("/menu","Web:menu");
$route->get("/inicio", "Web:home");
$route->get("/carrinho", "Web:cart");
$route->get("/admLogin", "Web:adm-login");
$route->get("/admRegister", "Web:adm-register");




$route->get("/", "Web:home");
$route->get("/sobre", "Web:about");
$route->get("/register", "Web:register");
$route->get("/login", "Web:login");
$route->get("/perfil", "App:profile"); 
$route->get("/faq", "Web:faq");
$route->get("/api-faqs", "Web:apiFaq");
$route->get("/api-login", "Web:apiLogin");
$route->get("/api-register", "Web:apiRegister");
$route->get("/pratos", "Web:dishes");
$route->get("/pratos/{categoryName}", "Web:dishes");


$route->group("/app");
$route->get("/", "App:home");  
$route->group(null);


$route->group("/admin");
$route->get("/", "Adm:home");
$route->get("/pratos", "Adm:dishes");
$route->group(null);

$route->dispatch();

if ($route->error()) {
    $route->redirect("/ops/{$route->error()}");
    var_dump($route);
}

ob_end_flush();